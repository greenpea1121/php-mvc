<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>檢視員工業績</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div>
		<header>
			<div class="container">
				<h1>檢視員工業績</h1>
				<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
					<ul class="navbar-nav">
						<li class="nav-item active">
							<a class="nav-link" href="../index.php">回主頁</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="employees.php">回員工管理系統</a>
						</li>
					</ul>
				</nav>
			</div>
		</header>
		<main>
			<div class="container">
				<form class="form-inline" method="post" active="<?php echo $_SERVER['PHP_SELF']; ?>">
					<div class="form-group px-2">
						<label class="px-1">年度</label>
						<select class="form-control" name="year">
							<option value="0">...請選擇年度</option>
							<option value="1996">1996</option>
							<option value="1997">1997</option>
						</select>
					</div>
					<div class="form-group px-2">
						<label class="px-1">月份</label>
						<select class="form-control" name="month">
							<option value="0">...請選擇月份</option>
							<option value="1">1</option>
							<option value="2">2</option>
							<option value="3">3</option>
							<option value="4">4</option>
							<option value="5">5</option>
							<option value="6">6</option>
							<option value="7">7</option>
							<option value="8">8</option>
							<option value="9">9</option>
							<option value="10">10</option>
							<option value="11">11</option>
							<option value="12">12</option>
						</select>
					</div>
					<div class="">
						<input type="submit" name="submit" value="查詢">
					</div>
				</form>
			</div>
			<div class="container">
			<?php
				if(!empty($_POST['submit'])){
					if($_POST['year'] == 0 or $_POST['month'] == 0){
						echo '忘記選擇年度或月份了';
					} else {
						//載入資料連線
						require_once('../phpscript/dbconnect.php');
						
						//儲存 POST 的變數值
						$year = $_POST['year'];
						$month = $_POST['month'];
						
						//建立 MySQL 查詢語法
						$sql = "SELECT ";


						echo '<p>年度： '.$year.'</p>';
						echo '<p>月份： '.$month.'</p>';
					}
				} else {
					echo '還未執行任何查詢';
				}
			?>	
			</div>



			<!--
			<div id="results" class="container">
				<table class="table table-hover table-striped">
					<thead class="thead-dark">
						<tr>
							<td>員工ID</td>
							<td>員工名</td>
							<td>員工姓</td>
						</tr>
					</thead>
					<tbody>
				<?php
				/*
					if (mysqli_num_rows($result) > 0) {
						while($row = mysqli_fetch_assoc($result)) {
							$msg = '<tr>';
							$msg .= '<td>'.$row['employeeid'].'</td>';
							$msg .= '<td>'.$row['firstname'].'</td>';
							$msg .= '<td>'.$row['lastname'].'</td>';
							$msg .= '</tr>';
							echo $msg;
						}
					} else {
				    echo "0 筆資料";
					}
				*/
				?>
					</tbody>	
				</table>
			</div>

			-->
		</main>
	</div>
</body>
</html>
<?php
	mysqli_close($con);
?>