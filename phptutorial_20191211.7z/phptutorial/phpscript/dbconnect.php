<?php
	//匯入 constants.php 檔案內的常數
	require_once('constants.php');

	//建立 $con 變數，儲存 MySQL 的連結
	$con = mysqli_connect(HOST,ID,PW,DB);

	//判斷資料庫連結是否正常
	//寫法一
	if(!$con){
		$msg = '<h3>Connection Failed</h3>';
		$msg .= '<h4>Error Number: <span style="color:red;">'.mysqli_connect_errno().'</span></h4>';
		$msg .= '<h4>Error Message: <span style="color:red;">'.mysqli_connect_error().'</span></h4>';
		die($msg);
	}
	//echo '<h3 style="color:lightgreen;">資料庫連結成功</h3>';


	//寫法二
	/*多行註解
	if($con){
		echo '資料庫連結成功';
	} else {
		die("Connection failed: " . mysqli_connect_error());
	}
	*/
	
?>