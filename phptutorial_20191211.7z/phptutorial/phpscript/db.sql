USE w3schools;

/*檢視員工業績*/
SELECT
	e.employeeid AS eid,
	CONCAT_WS('.,',LEFT(e.firstname,1),e.lastname) AS name,
	IFNULL(sq.amount,0) AS amount
FROM employees AS e
	LEFT JOIN (
		SELECT
			o.employeeid AS employeeid,
			SUM(od.quantity * p.price) AS amount
		FROM orders AS o
			INNER JOIN orderdetails AS od USING(orderid)
			INNER JOIN products AS p USING(productid)
		WHERE YEAR(o.orderdate) = 1996 AND MONTH(o.orderdate) = 7
		GROUP BY employeeid
	) AS sq USING(employeeid);


/*單一員工業績總合*/
SELECT
	o.orderid AS orderid,
	SUM(od.quantity * p.price) AS amount
FROM orders AS o
	INNER JOIN orderdetails AS od USING(orderid)
	INNER JOIN products AS p USING(productid)
WHERE YEAR(o.orderdate) = 1997 AND MONTH(o.orderdate) = 2
	AND o.employeeid = 3
GROUP BY orderid";