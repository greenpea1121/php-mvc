<?php
	
			//儲存 POST 的變數值
			$year = $_GET['year'];
			$month = $_GET['month'];
			$eid = $_GET['eid'];
			
			//載入資料連線
			require_once('../phpscript/dbconnect.php');
			
			//建立 MySQL 查詢語法
			$sql = "
						SELECT
							o.orderid AS orderid,
							SUM(od.quantity * p.price) AS amount
						FROM orders AS o
							INNER JOIN orderdetails AS od USING(orderid)
							INNER JOIN products AS p USING(productid)
						WHERE YEAR(o.orderdate) = $year AND MONTH(o.orderdate) = $month 
							AND o.employeeid = $eid
						GROUP BY orderid";

			$result = mysqli_query($con,$sql);

			mysqli_close($con);
		
?>


<div id="results" class="container py-2">
	<table class="table table-hover table-striped">
		<thead class="thead-dark">
			<tr>
				<td>訂單編號</td>
				<td>訂單總額</td>
			</tr>
		</thead>
		<tbody>


	<?php
		if(mysqli_num_rows($result) > 0) {
			while($row = mysqli_fetch_assoc($result)) {
				$msg = '<tr>';
				$msg .= '<td>'.$row['orderid'].'</td>';
				$msg .= '<td>'.$row['amount'].'</td>';
				$msg .= '</tr>';
				echo $msg;
			}
		} else {
	    echo "查無資料";
		}
	?>


		</tbody>	
	</table>
</div>
	
