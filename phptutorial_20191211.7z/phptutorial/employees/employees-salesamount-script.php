<?php
	if(!empty($_POST['submit'])){
		if($_POST['year'] == 0 or $_POST['month'] == 0){
			echo '忘記選擇年度或月份了';
		} else {
			//儲存 POST 的變數值
			$year = $_POST['year'];
			$month = $_POST['month'];
			
			//載入資料連線
			require_once('../phpscript/dbconnect.php');
			
			//建立 MySQL 查詢語法
			$sql = "
				SELECT
					e.employeeid AS eid,
					CONCAT_WS('. ',LEFT(e.firstname,1),e.lastname) AS name,
					IFNULL(sq.amount,0) AS amount
				FROM employees AS e
					LEFT JOIN (
						SELECT
							o.employeeid AS employeeid,
							SUM(od.quantity * p.price) AS amount
						FROM orders AS o
							INNER JOIN orderdetails AS od USING(orderid)
							INNER JOIN products AS p USING(productid)
						WHERE YEAR(o.orderdate) = $year AND MONTH(o.orderdate) = $month
						GROUP BY employeeid
					) AS sq USING(employeeid);";

			$result = mysqli_query($con,$sql);

			mysqli_close($con);
		
?>


<div id="results" class="container py-2">
	<h2 class="py-2"><?php echo $year; ?>年<?php echo $month; ?>月員工業績統計表</h2>
	<table class="table table-hover table-striped">
		<thead class="thead-dark">
			<tr>
				<td>員工ID</td>
				<td>姓名</td>
				<td>業績總額</td>
			</tr>
		</thead>
		<tbody>


	<?php
		if(mysqli_num_rows($result) > 0) {
			while($row = mysqli_fetch_assoc($result)) {
				$msg = '<tr>';
				$msg .= '<td><a href="employees-personsalesamount.php?eid='.$row['eid'];
				$msg .= '&name='.$row['name'].'&year='.$year.'&month='.$month;
				$msg .= '" target="_blank">'.$row['eid'].'</a></td>';
				$msg .= '<td>'.$row['name'].'</td>';
				$msg .= '<td>'.$row['amount'].'</td>';
				$msg .= '</tr>';
				echo $msg;
			}
		} else {
	    echo "查無資料";
		}
	?>


		</tbody>	
	</table>
</div>

<?php
		}
	} else {
		echo '還未執行任何查詢';
	}
?>	
