<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>單一員工業績</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div>
		<header>
			<div class="container">
				<h1>單一員工業績</h1>
				<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
					<ul class="navbar-nav">
						<li class="nav-item active">
							<a class="nav-link" href="../index.php">回主頁</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="employees.php">回員工管理系統</a>
						</li>
					</ul>
				</nav>
			</div>
		</header>
		<main>
			<div class="container py-2">
				<h2>
					<?php 
						echo $_GET['year'].'年'.$_GET['month'].'月  '.$_GET['name'].'業績明細表'
					?>
				</h2>
			</div>
			<div class="container">
			<?php
				require_once('employees-personsalesamount-script.php');
			?>	
		</main>
	</div>
</body>
</html>
