<?php
	require_once('../phpscript/dbconnect.php');

	//建立 MySQL 查詢字串
	$sql = "SELECT 
						employeeid,
						firstname,
						lastname
					FROM employees;";

	//啟動資料庫查詢
	$result = mysqli_query($con,$sql);

	
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>檢視員工</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div>
		<header>
			<div class="container">
				<h1>檢視員工</h1>
				<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
					<ul class="navbar-nav">
						<li class="nav-item active">
							<a class="nav-link" href="../index.php">回主頁</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="employees.php">回員工管理系統</a>
						</li>
					</ul>
				</nav>
			</div>
		</header>
		<main>
			<div id="results" class="container">
				<div>
					<section>員工ID</section>
					<section>員工名</section>
					<section>員工姓</section>
				</div>
			<?php
				if (mysqli_num_rows($result) > 0) {
					while($row = mysqli_fetch_assoc($result)) {
						$msg = '<div>';
						$msg .= '<section>'.$row['employeeid'].'</section>';
						$msg .= '<section>'.$row['firstname'].'</section>';
						$msg .= '<section>'.$row['lastname'].'</section>';
						$msg .= '</div>';
						echo $msg;
					}
				} else {
			    echo "0 筆資料";
				}
			?>	
			</div>
		</main>
	</div>
</body>
</html>
<?php
	mysqli_close($con);
?>