<?php
	define('HOST','localhost');
	define('ID','root');
	define('PW','');
	define('DB','w3schools');
?>